-- Phase 0 house tables on helomatic-shop.
-- Do not drop the empty shop schema used by sibling experiments.
-- jobs / sessions / stripe_events already exist with a different shape (0 rows).
-- House loop tables below do not collide. partner_id NULL = Helomatic self.

CREATE TABLE IF NOT EXISTS partners (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  branding_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  sku TEXT NOT NULL DEFAULT 'web',
  mode TEXT,
  source_url TEXT,
  name TEXT,
  brief_json TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  preview_ready INTEGER NOT NULL DEFAULT 0,
  publish_intent INTEGER NOT NULL DEFAULT 0,
  subdomain_placeholder TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS ledger (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  job_id TEXT,
  site_id TEXT,
  kind TEXT NOT NULL,
  stripe_event_id TEXT,
  stripe_object_id TEXT,
  status TEXT NOT NULL,
  note TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS waitlist (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  bay_index INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS brief_assets (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  kind TEXT NOT NULL,
  filename TEXT,
  content_type TEXT,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS mail_outbox (
  id TEXT PRIMARY KEY,
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'resend_stub',
  sent INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

-- Helomatic OS Phase 0 schema.
-- partner_id NULL means the house (Helomatic self). Do not insert a house partner row.

CREATE TABLE partners (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  branding_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL
);

CREATE TABLE customers (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (partner_id) REFERENCES partners(id)
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE sites (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  sku TEXT NOT NULL DEFAULT 'web',
  mode TEXT,
  source_url TEXT,
  name TEXT,
  brief_json TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  preview_ready INTEGER NOT NULL DEFAULT 0,
  publish_intent INTEGER NOT NULL DEFAULT 0,
  subdomain_placeholder TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (partner_id) REFERENCES partners(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE jobs (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  site_id TEXT,
  kind TEXT NOT NULL,
  status TEXT NOT NULL,
  payload_json TEXT,
  stripe_session_id TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (partner_id) REFERENCES partners(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (site_id) REFERENCES sites(id)
);

CREATE TABLE ledger (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  job_id TEXT,
  site_id TEXT,
  kind TEXT NOT NULL,
  stripe_event_id TEXT,
  stripe_object_id TEXT,
  status TEXT NOT NULL,
  note TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (partner_id) REFERENCES partners(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id),
  FOREIGN KEY (job_id) REFERENCES jobs(id),
  FOREIGN KEY (site_id) REFERENCES sites(id)
);

CREATE TABLE waitlist (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  bay_index INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (partner_id) REFERENCES partners(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE brief_assets (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  kind TEXT NOT NULL,
  filename TEXT,
  content_type TEXT,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (site_id) REFERENCES sites(id),
  FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE mail_outbox (
  id TEXT PRIMARY KEY,
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'resend_stub',
  sent INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE stripe_events (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  processed_at INTEGER NOT NULL
);

CREATE INDEX idx_sessions_customer ON sessions(customer_id);
CREATE INDEX idx_sites_customer ON sites(customer_id);
CREATE INDEX idx_jobs_site ON jobs(site_id);
CREATE INDEX idx_ledger_customer ON ledger(customer_id);
CREATE INDEX idx_waitlist_customer ON waitlist(customer_id);

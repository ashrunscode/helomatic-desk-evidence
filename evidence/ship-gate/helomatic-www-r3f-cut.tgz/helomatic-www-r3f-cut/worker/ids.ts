export const STATIC_ASSET_NAME =
  /\.(js|css|map|mjs|woff2?|ttf|svg|png|jpe?g|webp|ico)$/i;

export function isStaticAssetName(id: string): boolean {
  return STATIC_ASSET_NAME.test(id);
}

export function nid(prefix: string): string {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  const hex = [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
  return `${prefix}_${hex}`;
}

export function now(): number {
  return Date.now();
}

export function slugify(value: string): string {
  const slug = value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 32);
  return slug || "desk";
}

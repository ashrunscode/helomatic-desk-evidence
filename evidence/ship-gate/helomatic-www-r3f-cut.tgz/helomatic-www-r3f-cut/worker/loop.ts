export type LoopStep = "land" | "choose" | "brief" | "preview" | "print" | "ticket";

export type LoopNext = {
  step: LoopStep;
  href: string;
  label: string;
};

export function nextOnLoop(
  sites: Pick<SiteRow, "id" | "sku" | "status" | "preview_ready">[],
): LoopNext {
  const web = sites.find((s) => s.sku === "web");
  if (!web) return { step: "choose", href: "/choose", label: "Choose Web" };
  if (!web.preview_ready || web.status === "draft") {
    return { step: "brief", href: `/brief/${web.id}`, label: "File the brief" };
  }
  if (web.status === "preview") {
    return { step: "preview", href: `/preview/${web.id}`, label: "Open gated preview" };
  }
  return { step: "ticket", href: `/job?site=${web.id}`, label: "Open the job ticket" };
}

export const LOOP_STEPS: { id: LoopStep; label: string }[] = [
  { id: "land", label: "Land" },
  { id: "choose", label: "Choose Web" },
  { id: "brief", label: "Brief" },
  { id: "preview", label: "Preview" },
  { id: "print", label: "Print it" },
];

import { publicHttpUrl } from "./frame.ts";

const MAX_BYTES = 400_000;

export type IngestDocument = {
  status: number;
  html: string;
  host: string;
};

export async function fetchIngestDocument(
  raw: string,
  fetchImpl: typeof fetch = fetch,
): Promise<IngestDocument> {
  const url = publicHttpUrl(raw);
  if (!url) return { status: 400, host: "", html: noticePage("That URL is not fetchable.") };
  try {
    const res = await fetchImpl(url.toString(), {
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
      headers: {
        Accept: "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
        "User-Agent": "HelomaticDesk/1.0",
      },
    });
    const buf = new Uint8Array(await res.arrayBuffer());
    const sliced = buf.byteLength > MAX_BYTES ? buf.subarray(0, MAX_BYTES) : buf;
    const text = new TextDecoder("utf-8", { fatal: false }).decode(sliced);
    const ct = res.headers.get("content-type") ?? "";
    if (!/text\/html|application\/xhtml/i.test(ct) && !/^\s*</.test(text)) {
      return {
        status: 200,
        host: url.hostname,
        html: noticePage(`Fetched ${url.hostname}. This response is not a page.`),
      };
    }
    return { status: 200, host: url.hostname, html: rewriteForFrame(text, url) };
  } catch {
    return { status: 502, host: url.hostname, html: noticePage(`Could not fetch ${url.hostname}.`) };
  }
}

export function rewriteForFrame(html: string, url: URL): string {
  const href = url.href;
  let next = html.replace(/<base\b[^>]*>/gi, "");
  next = next.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "").replace(/<script\b[^>]*\/?>/gi, "");
  const base = `<base href="${escAttr(href)}">`;
  const head = /<head(\s[^>]*)?>/i.exec(next);
  const root = /<html(\s[^>]*)?>/i.exec(next);
  if (head) {
    next = next.replace(head[0], `${head[0]}${base}`);
  } else if (root) {
    next = next.replace(root[0], `${root[0]}<head>${base}</head>`);
  } else {
    next = `<!doctype html><html><head>${base}</head><body>${next}</body></html>`;
  }
  next = next.replace(/<meta[^>]+http-equiv=["']?refresh["']?[^>]*>/gi, "");
  if (isAppShell(next)) next = paintFetchedStill(next, url);
  return next;
}

function isAppShell(html: string): boolean {
  const body = /<body\b[^>]*>([\s\S]*)<\/body>/i.exec(html);
  const inner = (body?.[1] ?? html).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, "");
  const text = inner.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  return text.length < 8;
}

function paintFetchedStill(html: string, url: URL): string {
  const title = (/<title[^>]*>([^<]+)/i.exec(html)?.[1] ?? url.hostname).trim();
  const image =
    /<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)/i.exec(html)?.[1] ??
    /<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i.exec(html)?.[1] ??
    "";
  const desc =
    /<meta[^>]+property=["']og:description["'][^>]+content=["']([^"']+)/i.exec(html)?.[1] ??
    /<meta[^>]+name=["']description["'][^>]+content=["']([^"']+)/i.exec(html)?.[1] ??
    url.href;
  const wordmark = title.split(/\s+[—–|-]\s+/)[0]?.trim() || url.hostname;
  const picture = image
    ? `<img src="${escAttr(image)}" alt="${escAttr(title)}">`
    : `<span class="empty">${escAttr(wordmark.slice(0, 1))}</span>`;
  return `<!doctype html><html><head><meta charset="utf-8"><base href="${escAttr(url.href)}"><title>${escAttr(title)}</title>
<style>
html,body{margin:0;min-height:100%;background:#f4f4f1;color:#161614}
.page{min-height:100%;display:flex;flex-direction:column}
.bar{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:10px 16px;border-bottom:1px solid #d8d8d2;background:#fff}
.mark{font:13px/1 Segoe UI,sans-serif;letter-spacing:.01em}
.links{display:flex;gap:14px;font:12px/1 Segoe UI,sans-serif;color:#4a4a46}
.crumb{display:flex;gap:12px;padding:8px 16px;border-bottom:1px solid #e6e6e0;background:#fafaf7;font:11px/1 Segoe UI,sans-serif;color:#6a6a64}
.mast{display:grid;grid-template-columns:72px 1fr;gap:14px;padding:16px;align-items:start;background:#fff;border-bottom:1px solid #e6e6e0}
.mast .kicker{margin:0;font:11px/1 Segoe UI,sans-serif;letter-spacing:.08em;text-transform:uppercase;color:#7a7a74}
.mast h1{margin:6px 0 0;font:22px/1.2 "Iowan Old Style",Georgia,serif;font-weight:400;letter-spacing:-.03em}
.mast p{margin:8px 0 0;max-width:36rem;font:13px/1.45 Segoe UI,sans-serif;color:#3a3a36}
.media{width:72px;height:72px;overflow:hidden;background:#ecece6;border:1px solid #d8d8d2}
.media img{display:block;width:100%;height:100%;object-fit:cover;object-position:top center}
.media .empty{display:grid;place-items:center;height:100%;font:18px/1 Georgia,serif;color:#8b8b86}
.pages{padding:14px 16px 4px;background:#f4f4f1}
.pages h2,.row h2{margin:0 0 8px;font:11px/1 Segoe UI,sans-serif;letter-spacing:.07em;text-transform:uppercase;color:#7a7a74}
.pages ul{margin:0;padding:0;list-style:none;border:1px solid #d8d8d2;background:#fff}
.pages li{display:flex;justify-content:space-between;gap:12px;padding:10px 12px;border-top:1px solid #ecece6;font:13px/1.35 Segoe UI,sans-serif}
.pages li:first-child{border-top:0}
.pages b{font-weight:500}
.pages span{color:#6a6a64}
.row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;padding:12px 16px 16px}
.row > div{padding:12px;border:1px solid #d8d8d2;background:#fff}
.row p{margin:8px 0 0;font:13px/1.45 Segoe UI,sans-serif;color:#3a3a36}
.foot{margin-top:auto;padding:12px 16px;border-top:1px solid #d8d8d2;background:#fff;font:11px/1 Segoe UI,sans-serif;color:#7a7a74}
@media (max-width:640px){.row{grid-template-columns:1fr}}
</style>
</head><body><div class="page"><header class="bar"><span class="mark">${escAttr(wordmark)}</span><nav class="links"><span>Work</span><span>Studio</span><span>Contact</span></nav></header><nav class="crumb"><span>Home</span><span>Work</span><span>Studio</span><span>Contact</span></nav><section class="mast"><div class="media">${picture}</div><div><p class="kicker">${escAttr(url.hostname)}</p><h1>${escAttr(title)}</h1><p>${escAttr(desc)}</p></div></section><section class="pages"><h2>On this site</h2><ul><li><b>Home</b><span>Live homepage</span></li><li><b>Work</b><span>Selected pages stay on the live site.</span></li><li><b>Studio</b><span>${escAttr(wordmark)}</span></li><li><b>Contact</b><span>${escAttr(url.hostname)}</span></li></ul></section><section class="row"><div><h2>Work</h2><p>Selected pages stay on the live site.</p></div><div><h2>Studio</h2><p>${escAttr(wordmark)}</p></div><div><h2>Contact</h2><p>${escAttr(url.hostname)}</p></div></section><footer class="foot">${escAttr(url.hostname)}</footer></div></body></html>`;
}

function noticePage(message: string): string {
  return `<!doctype html><html><head><meta charset="utf-8"><title>Desk</title>
<style>body{margin:0;background:#fff;color:#0c0c0c;font:16px/1.45 Georgia,serif;padding:24px}</style>
</head><body><p>${escAttr(message)}</p></body></html>`;
}

function escAttr(value: string): string {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
}

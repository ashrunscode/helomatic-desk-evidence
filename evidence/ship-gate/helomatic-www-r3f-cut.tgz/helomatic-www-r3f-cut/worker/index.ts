import { Hono } from "hono";
import { getCookie } from "hono/cookie";
import {
  clearSessionCookie,
  createSession,
  customerFromRequest,
  hashPassword,
  isSecureRequest,
  publicCustomer,
  sessionCookie,
  verifyPassword,
} from "./auth";
import { isStaticAssetName, nid, now, slugify } from "./ids";
import {
  attachAssetCors,
  isWorkerStaticAssetPath,
  shouldAttachContentSignal,
  staticAssetPreflight,
} from "./static-asset";
import { nextOnLoop } from "./loop";
import { queueMail } from "./mail";
import { mcpFetch } from "./mcp";
import { ensureSchema } from "./schema";
import { AgentDesk } from "./objects/agent-desk";
import { LiveChat } from "./objects/live-chat";
import { VisitorGlobe } from "./objects/visitor-globe";
import { probeFrame } from "./frame";
import { fetchIngestDocument } from "./ingest-page";
import { gatedPreviewPage, renderPreviewHtml, type Brief } from "./preview";
import {
  createPrintCheckout,
  handleStripeWebhook,
  recordPrintJob,
  stripeReady,
} from "./stripe";
import {
  agentIndex,
  jsonLd,
  llmsFullTxt,
  llmsTxt,
  markdownPage,
  robotsTxt,
  withSignal,
} from "./visibility";

export { AgentDesk, LiveChat, VisitorGlobe };

const app = new Hono<{ Bindings: Env }>();

app.onError((err, c) => {
  console.error(err);
  return c.json({ error: err.message || "desk error" }, 500);
});

app.use("*", async (c, next) => {
  if (c.req.header("Upgrade") === "websocket") {
    await next();
    return;
  }
  await next();
  const ct = c.res.headers.get("content-type") ?? "";
  if (!shouldAttachContentSignal(ct)) return;
  const nextRes = new Response(c.res.body, c.res);
  nextRes.headers.set("Content-Signal", "ai-input=yes, search=yes, ai-train=no");
  c.res = nextRes;
});

app.get("/api/health", (c) =>
  c.json({
    ok: true,
    house: "helomatic-www",
    sku: "web",
    stripe: stripeReady(c.env) ? "configured" : "stub",
    workers_dev: "helomatic-www.ernijs-ansons.workers.dev",
  }),
);

app.get("/api/reprint/frame", async (c) => {
  const url = c.req.query("url") ?? "";
  return c.json(await probeFrame(url));
});

app.get("/api/ingest/page", async (c) => {
  const { status, html } = await fetchIngestDocument(c.req.query("url") ?? "");
  return new Response(html, {
    status,
    headers: {
      "content-type": "text/html; charset=utf-8",
      "content-security-policy": "frame-ancestors 'self'",
      "x-frame-options": "SAMEORIGIN",
      "cache-control": "no-store",
    },
  });
});

app.get("/llms.txt", () => withSignal(new Response(llmsTxt(), { headers: { "content-type": "text/plain; charset=utf-8" } })));
app.get("/llms-full.txt", () =>
  withSignal(new Response(llmsFullTxt(), { headers: { "content-type": "text/plain; charset=utf-8" } })),
);
app.get("/robots.txt", () =>
  withSignal(new Response(robotsTxt(), { headers: { "content-type": "text/plain; charset=utf-8" } })),
);
app.get("/index.json", () => withSignal(Response.json(agentIndex())));
app.get("/jsonld", () => withSignal(Response.json(jsonLd())));

app.get("/web.md", () =>
  withSignal(new Response(markdownPage("web") ?? "", { headers: { "content-type": "text/markdown; charset=utf-8" } })),
);
app.get("/desk.md", () =>
  withSignal(new Response(markdownPage("desk") ?? "", { headers: { "content-type": "text/markdown; charset=utf-8" } })),
);

app.post("/api/auth/signup", async (c) => {
  const body = (await c.req.json()) as { email?: string; password?: string; name?: string };
  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";
  const name = (body.name ?? "").trim().slice(0, 80);
  if (!email.includes("@") || password.length < 8) {
    return c.json({ error: "Email and a password of at least 8 characters are required." }, 400);
  }
  const existing = await c.env.DB.prepare("SELECT id FROM customers WHERE email = ?")
    .bind(email)
    .first();
  if (existing) return c.json({ error: "That desk already exists. Sign in." }, 409);
  const id = nid("cus");
  const created = now();
  await c.env.DB.prepare(
    `INSERT INTO customers (id, partner_id, email, password_hash, display_name, created_at)
     VALUES (?, NULL, ?, ?, ?, ?)`,
  )
    .bind(id, email, await hashPassword(password), name || null, created)
    .run();
  const sid = await createSession(c.env.DB, id);
  await queueMail(
    c.env.DB,
    email,
    "Desk opened",
    "Your Helomatic desk is open. This mail was stubbed and not sent.",
  );
  const customer = await c.env.DB.prepare("SELECT * FROM customers WHERE id = ?")
    .bind(id)
    .first<CustomerRow>();
  return c.json(
    { customer: customer ? publicCustomer(customer) : null },
    201,
    { "Set-Cookie": sessionCookie(sid, isSecureRequest(c.req.raw)) },
  );
});

app.post("/api/auth/login", async (c) => {
  const body = (await c.req.json()) as { email?: string; password?: string };
  const email = (body.email ?? "").trim().toLowerCase();
  const row = await c.env.DB.prepare("SELECT * FROM customers WHERE email = ?")
    .bind(email)
    .first<CustomerRow>();
  if (!row || !(await verifyPassword(body.password ?? "", row.password_hash))) {
    return c.json({ error: "Those credentials do not open a desk." }, 401);
  }
  const sid = await createSession(c.env.DB, row.id);
  return c.json(
    { customer: publicCustomer(row) },
    200,
    { "Set-Cookie": sessionCookie(sid, isSecureRequest(c.req.raw)) },
  );
});

app.post("/api/auth/logout", (c) => {
  return c.json({ ok: true }, 200, {
    "Set-Cookie": clearSessionCookie(isSecureRequest(c.req.raw)),
  });
});

app.get("/api/auth/me", async (c) => {
  const customer = await customerFromRequest(c.env.DB, c.req.raw);
  if (!customer) return c.json({ customer: null }, 200);
  return c.json({ customer: publicCustomer(customer) });
});

async function requireCustomer(c: { env: Env; req: { raw: Request } }) {
  const customer = await customerFromRequest(c.env.DB, c.req.raw);
  return customer;
}

app.get("/api/desk", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const sites = await c.env.DB.prepare(
    "SELECT * FROM sites WHERE customer_id = ? ORDER BY created_at DESC",
  )
    .bind(customer.id)
    .all<SiteRow>();
  const jobs = await c.env.DB.prepare(
    "SELECT * FROM jobs WHERE customer_id = ? ORDER BY created_at DESC LIMIT 20",
  )
    .bind(customer.id)
    .all<JobRow>();
  const wait = await c.env.DB.prepare(
    "SELECT bay_index, created_at FROM waitlist WHERE customer_id = ? ORDER BY bay_index",
  )
    .bind(customer.id)
    .all<{ bay_index: number; created_at: number }>();
  const list = sites.results ?? [];
  return c.json({
    customer: publicCustomer(customer),
    sites: list,
    jobs: jobs.results ?? [],
    waitlist: wait.results ?? [],
    next: nextOnLoop(list),
  });
});

app.post("/api/choose/web", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const open = await c.env.DB.prepare(
    `SELECT * FROM sites WHERE customer_id = ? AND sku = 'web' AND status IN ('draft', 'preview')
     ORDER BY created_at DESC`,
  )
    .bind(customer.id)
    .first<SiteRow>();
  if (open) {
    return c.json({ site: open, resumed: true, next: nextOnLoop([open]) });
  }
  const id = nid("site");
  const created = now();
  await c.env.DB.prepare(
    `INSERT INTO sites (id, partner_id, customer_id, sku, status, created_at, updated_at)
     VALUES (?, ?, ?, 'web', 'draft', ?, ?)`,
  )
    .bind(id, customer.partner_id, customer.id, created, created)
    .run();
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ?").bind(id).first<SiteRow>();
  return c.json({ site, resumed: false, next: site ? nextOnLoop([site]) : nextOnLoop([]) }, 201);
});

app.post("/api/bays/:index/waitlist", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const index = Number(c.req.param("index"));
  if (![2, 3, 4, 5, 6].includes(index)) return c.json({ error: "empty bay only" }, 400);
  const existing = await c.env.DB.prepare(
    "SELECT id FROM waitlist WHERE customer_id = ? AND bay_index = ?",
  )
    .bind(customer.id, index)
    .first();
  if (existing) return c.json({ ok: true, already: true });
  await c.env.DB.prepare(
    "INSERT INTO waitlist (id, partner_id, customer_id, bay_index, created_at) VALUES (?, ?, ?, ?, ?)",
  )
    .bind(nid("wait"), customer.partner_id, customer.id, index, now())
    .run();
  return c.json({ ok: true });
});

app.get("/api/sites/:id", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site) return c.json({ error: "not found" }, 404);
  const assets = await c.env.DB.prepare("SELECT * FROM brief_assets WHERE site_id = ?")
    .bind(site.id)
    .all<BriefAssetRow>();
  const jobs = await c.env.DB.prepare(
    "SELECT * FROM jobs WHERE site_id = ? ORDER BY created_at DESC",
  )
    .bind(site.id)
    .all<JobRow>();
  return c.json({ site, assets: assets.results ?? [], jobs: jobs.results ?? [] });
});

app.post("/api/sites/:id/brief", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site) return c.json({ error: "not found" }, 404);
  const body = (await c.req.json()) as Brief & { mode?: string; source_url?: string };
  const mode = body.mode === "reprint" ? "reprint" : "scratch";
  if (mode === "reprint" && !body.source_url) {
    return c.json({ error: "Reprint needs a live URL." }, 400);
  }
  const name = (body.business_name ?? "").trim() || site.name || "Untitled";
  const created = now();
  const placeholder = `${slugify(name)}-pending-ernie`;
  await c.env.DB.prepare(
    `UPDATE sites SET mode = ?, source_url = ?, name = ?, brief_json = ?, status = 'preview',
     preview_ready = 1, subdomain_placeholder = ?, updated_at = ? WHERE id = ?`,
  )
    .bind(
      mode,
      mode === "reprint" ? body.source_url ?? null : null,
      name,
      JSON.stringify(body),
      placeholder,
      created,
      site.id,
    )
    .run();
  const next = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ?").bind(site.id).first<SiteRow>();
  return c.json({ site: next });
});

app.post("/api/sites/:id/assets", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site) return c.json({ error: "not found" }, 404);
  const form = await c.req.formData();
  const file = form.get("file");
  const kind = String(form.get("kind") ?? "photo");
  if (!(file instanceof File)) return c.json({ error: "file required" }, 400);
  if (kind !== "logo" && kind !== "photo") return c.json({ error: "kind" }, 400);
  const id = nid("ast");
  const key = `${customer.id}/${site.id}/${id}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
  await c.env.BRIEFS.put(key, await file.arrayBuffer(), {
    httpMetadata: { contentType: file.type || "application/octet-stream" },
  });
  await c.env.DB.prepare(
    `INSERT INTO brief_assets (id, site_id, customer_id, r2_key, kind, filename, content_type, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  )
    .bind(id, site.id, customer.id, key, kind, file.name, file.type, now())
    .run();
  return c.json({ id, kind }, 201);
});

app.get("/assets/:id", async (c) => {
  const id = c.req.param("id");
  if (isStaticAssetName(id) && c.env.ASSETS) {
    return attachAssetCors(await c.env.ASSETS.fetch(c.req.raw));
  }
  const customer = await requireCustomer(c);
  if (!customer) return c.body(null, 401);
  const asset = await c.env.DB.prepare(
    "SELECT * FROM brief_assets WHERE id = ? AND customer_id = ?",
  )
    .bind(c.req.param("id"), customer.id)
    .first<BriefAssetRow>();
  if (!asset) return c.body(null, 404);
  const obj = await c.env.BRIEFS.get(asset.r2_key);
  if (!obj) return c.body(null, 404);
  return new Response(obj.body, {
    headers: {
      "content-type": asset.content_type || "application/octet-stream",
      "cache-control": "private, max-age=300",
    },
  });
});

app.get("/p/:id", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return new Response(gatedPreviewPage(), { status: 401, headers: { "content-type": "text/html; charset=utf-8" } });
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site || !site.preview_ready) {
    return new Response(gatedPreviewPage(), { status: 404, headers: { "content-type": "text/html; charset=utf-8" } });
  }
  const assets = await c.env.DB.prepare("SELECT * FROM brief_assets WHERE site_id = ?")
    .bind(site.id)
    .all<BriefAssetRow>();
  const brief = (site.brief_json ? JSON.parse(site.brief_json) : {}) as Brief;
  return new Response(renderPreviewHtml({ site, brief, assets: assets.results ?? [] }), {
    headers: { "content-type": "text/html; charset=utf-8", "x-helomatic-preview": "session-gated" },
  });
});

app.post("/api/sites/:id/print", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site || !site.preview_ready) return c.json({ error: "preview not ready" }, 400);
  const origin = new URL(c.req.url).origin;
  if (stripeReady(c.env)) {
    const url = await createPrintCheckout(c.env, origin, site, customer);
    return c.json({ mode: "checkout", url });
  }
  const job = await recordPrintJob(c.env.DB, site, customer, { stub: true });
  return c.json({
    mode: "stub",
    job,
    message:
      "Stripe TEST keys are not configured. The desk recorded a TEST stub: Setup + Hosting, unpublished. The job is on the spike.",
  });
});

app.post("/api/webhooks/stripe", (c) => handleStripeWebhook(c.env, c.req.raw));

app.post("/api/sites/:id/changes", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site) return c.json({ error: "not found" }, 404);
  const body = (await c.req.json()) as { note?: string };
  const note = (body.note ?? "").trim();
  if (!note) return c.json({ error: "note required" }, 400);
  const created = now();
  const id = nid("job");
  await c.env.DB.prepare(
    `INSERT INTO jobs (id, partner_id, customer_id, site_id, kind, status, payload_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'change', 'queued', ?, ?, ?)`,
  )
    .bind(id, customer.partner_id, customer.id, site.id, JSON.stringify({ note }), created, created)
    .run();
  await c.env.DB.prepare("UPDATE sites SET status = ?, updated_at = ? WHERE id = ?")
    .bind("changes", created, site.id)
    .run();
  await queueMail(c.env.DB, customer.email, "Change on the desk", `Change job ${id} queued. Stub mail.`);
  const job = await c.env.DB.prepare("SELECT * FROM jobs WHERE id = ?").bind(id).first<JobRow>();
  return c.json({ job }, 201);
});

app.post("/api/sites/:id/publish", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const site = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<SiteRow>();
  if (!site) return c.json({ error: "not found" }, 404);
  const created = now();
  const placeholder = site.subdomain_placeholder || `${slugify(site.name || "desk")}-pending-ernie`;
  await c.env.DB.prepare(
    "UPDATE sites SET publish_intent = 1, status = ?, subdomain_placeholder = ?, updated_at = ? WHERE id = ?",
  )
    .bind("publish_intent", placeholder, created, site.id)
    .run();
  const id = nid("job");
  await c.env.DB.prepare(
    `INSERT INTO jobs (id, partner_id, customer_id, site_id, kind, status, payload_json, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'publish', 'waiting_ernie', ?, ?, ?)`,
  )
    .bind(
      id,
      customer.partner_id,
      customer.id,
      site.id,
      JSON.stringify({ subdomain_placeholder: placeholder, live_dns: "ernie" }),
      created,
      created,
    )
    .run();
  const next = await c.env.DB.prepare("SELECT * FROM sites WHERE id = ?").bind(site.id).first<SiteRow>();
  return c.json({
    site: next,
    job_id: id,
    note: "Publish intent filed. Live DNS is still a human named Ernie.",
  });
});

app.get("/api/jobs/:id", async (c) => {
  const customer = await requireCustomer(c);
  if (!customer) return c.json({ error: "signin" }, 401);
  const job = await c.env.DB.prepare("SELECT * FROM jobs WHERE id = ? AND customer_id = ?")
    .bind(c.req.param("id"), customer.id)
    .first<JobRow>();
  if (!job) return c.json({ error: "not found" }, 404);
  return c.json({ job });
});

app.get("/live/ws", (c) => {
  const id = c.env.LIVE_CHAT.idFromName("house");
  return c.env.LIVE_CHAT.get(id).fetch(c.req.raw);
});

app.get("/visitors/ws", (c) => {
  const id = c.env.VISITOR_GLOBE.idFromName("house");
  return c.env.VISITOR_GLOBE.get(id).fetch(c.req.raw);
});

app.all("/agent/ws", (c) => {
  const sid = getCookie(c, "desk_session") || "anon";
  const id = c.env.AGENT_DESK.idFromName(sid);
  return c.env.AGENT_DESK.get(id).fetch(c.req.raw);
});

app.all("/api/agent/chat", (c) => {
  const sid = getCookie(c, "desk_session") || "anon";
  const id = c.env.AGENT_DESK.idFromName(sid);
  return c.env.AGENT_DESK.get(id).fetch(c.req.raw);
});

export default {
  async fetch(request: Request, env: Env, ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    if (isWorkerStaticAssetPath(url.pathname) && env.ASSETS) {
      if (request.method === "OPTIONS") return staticAssetPreflight();
      return attachAssetCors(await env.ASSETS.fetch(request));
    }
    await ensureSchema(env.DB);
    if (url.pathname === "/mcp" || url.pathname.startsWith("/mcp/")) {
      if (request.method === "GET" || request.method === "HEAD") {
        return withSignal(
          new Response("Helomatic MCP. POST JSON-RPC here via createMcpHandler.\n", {
            headers: { "content-type": "text/plain; charset=utf-8" },
          }),
        );
      }
      return mcpFetch(request, env, ctx);
    }
    return app.fetch(request, env, ctx);
  },
};

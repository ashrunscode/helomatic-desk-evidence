import { nid, now } from "./ids";

const encoder = new TextEncoder();
const COOKIE = "desk_session";
const DAY = 1000 * 60 * 60 * 24;

function b64(bytes: Uint8Array): string {
  let bin = "";
  for (const byte of bytes) bin += String.fromCharCode(byte);
  return btoa(bin);
}

function unb64(value: string): Uint8Array {
  const bin = atob(value);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export async function hashPassword(password: string, salt?: Uint8Array): Promise<string> {
  const used = salt ?? crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, [
    "deriveBits",
  ]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: used as BufferSource, iterations: 120_000, hash: "SHA-256" },
    key,
    256,
  );
  return `pbkdf2$120000$${b64(used)}$${b64(new Uint8Array(bits))}`;
}

export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const parts = stored.split("$");
  if (parts.length !== 4 || parts[0] !== "pbkdf2") return false;
  const salt = unb64(parts[2]);
  const next = await hashPassword(password, salt);
  return next === stored;
}

export function readSessionId(request: Request): string | null {
  const header = request.headers.get("Cookie") ?? "";
  for (const part of header.split(";")) {
    const [rawKey, ...rest] = part.trim().split("=");
    if (rawKey === COOKIE) return decodeURIComponent(rest.join("="));
  }
  return null;
}

export function sessionCookie(id: string, secure: boolean): string {
  const attrs = [
    `${COOKIE}=${encodeURIComponent(id)}`,
    "Path=/",
    "HttpOnly",
    "SameSite=Lax",
    `Max-Age=${60 * 60 * 24 * 14}`,
  ];
  if (secure) attrs.push("Secure");
  return attrs.join("; ");
}

export function clearSessionCookie(secure: boolean): string {
  const attrs = [`${COOKIE}=`, "Path=/", "HttpOnly", "SameSite=Lax", "Max-Age=0"];
  if (secure) attrs.push("Secure");
  return attrs.join("; ");
}

export async function createSession(db: D1Database, customerId: string): Promise<string> {
  const id = nid("ses");
  const created = now();
  await db
    .prepare(
      "INSERT INTO sessions (id, customer_id, created_at, expires_at) VALUES (?, ?, ?, ?)",
    )
    .bind(id, customerId, created, created + DAY * 14)
    .run();
  return id;
}

export async function customerFromRequest(
  db: D1Database,
  request: Request,
): Promise<CustomerRow | null> {
  const sid = readSessionId(request);
  if (!sid) return null;
  const row = await db
    .prepare(
      `SELECT c.id, c.partner_id, c.email, c.password_hash, c.display_name, c.created_at
       FROM sessions s
       JOIN customers c ON c.id = s.customer_id
       WHERE s.id = ? AND s.expires_at > ?`,
    )
    .bind(sid, now())
    .first<CustomerRow>();
  return row ?? null;
}

export function publicCustomer(row: CustomerRow) {
  return {
    id: row.id,
    email: row.email,
    display_name: row.display_name,
    partner_id: row.partner_id,
  };
}

export function isSecureRequest(request: Request): boolean {
  return new URL(request.url).protocol === "https:";
}

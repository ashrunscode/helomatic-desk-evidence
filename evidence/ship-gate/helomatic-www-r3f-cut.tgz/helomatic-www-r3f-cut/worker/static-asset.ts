import { isStaticAssetName } from "./ids.ts";

export function isWorkerStaticAssetPath(pathname: string): boolean {
  const base = pathname.split("/").pop() ?? "";
  if (pathname === "/favicon.svg") return true;
  return pathname.startsWith("/assets/") && isStaticAssetName(base);
}

export function shouldAttachContentSignal(contentType: string): boolean {
  const ct = contentType.toLowerCase();
  if (ct.includes("css") || ct.includes("javascript") || ct.includes("font") || ct.includes("wasm")) {
    return false;
  }
  return ct.includes("html") || ct.includes("json") || ct.includes("text/plain");
}

export function attachAssetCors(res: Response): Response {
  const next = new Response(res.body, res);
  next.headers.set("Access-Control-Allow-Origin", "*");
  next.headers.set("Cross-Origin-Resource-Policy", "cross-origin");
  next.headers.set("Timing-Allow-Origin", "*");
  return next;
}

export function staticAssetPreflight(): Response {
  return new Response(null, {
    status: 204,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Max-Age": "86400",
      "Cross-Origin-Resource-Policy": "cross-origin",
    },
  });
}

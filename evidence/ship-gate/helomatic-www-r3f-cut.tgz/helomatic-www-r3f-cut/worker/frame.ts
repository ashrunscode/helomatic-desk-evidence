export type FrameReason = "ok" | "x-frame-options" | "csp" | "unreachable" | "blocked-url";

export type FrameProbe = {
  framed: boolean;
  host: string;
  reason: FrameReason;
};

const PRIVATE_HOST =
  /^(localhost|127\.|10\.|0\.0\.0\.0|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|\[::1\]|::1$)/i;

export function publicHttpUrl(raw: string): URL | null {
  try {
    const withProto = /^https?:\/\//i.test(raw.trim()) ? raw.trim() : `https://${raw.trim()}`;
    const url = new URL(withProto);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    if (PRIVATE_HOST.test(url.hostname)) return null;
    return url;
  } catch {
    return null;
  }
}

export function classifyFrameHeaders(headers: Headers): Exclude<FrameReason, "unreachable" | "blocked-url"> {
  const xfo = headers.get("x-frame-options") ?? "";
  if (/deny|sameorigin/i.test(xfo)) return "x-frame-options";
  const csp = headers.get("content-security-policy") ?? "";
  const ancestors = /frame-ancestors\s+([^;]+)/i.exec(csp);
  if (!ancestors) return "ok";
  const src = ancestors[1].trim().toLowerCase();
  if (src === "'none'" || src === "'self'" || src === "none" || src === "self") return "csp";
  if (src.includes("*")) return "ok";
  return "csp";
}

export async function probeFrame(raw: string, fetchImpl: typeof fetch = fetch): Promise<FrameProbe> {
  const url = publicHttpUrl(raw);
  if (!url) return { framed: false, host: "", reason: "blocked-url" };
  try {
    const res = await fetchImpl(url.toString(), {
      method: "HEAD",
      redirect: "follow",
      signal: AbortSignal.timeout(5000),
    });
    const reason = classifyFrameHeaders(res.headers);
    return { framed: reason === "ok", host: url.hostname, reason };
  } catch {
    try {
      const res = await fetchImpl(url.toString(), {
        method: "GET",
        redirect: "follow",
        signal: AbortSignal.timeout(5000),
        headers: { Range: "bytes=0-0" },
      });
      const reason = classifyFrameHeaders(res.headers);
      return { framed: reason === "ok", host: url.hostname, reason };
    } catch {
      return { framed: false, host: url.hostname, reason: "unreachable" };
    }
  }
}

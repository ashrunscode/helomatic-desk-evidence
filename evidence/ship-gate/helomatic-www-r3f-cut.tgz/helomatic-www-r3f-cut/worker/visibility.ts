const SIGNAL = "ai-input=yes, search=yes, ai-train=no";

export function withSignal(response: Response): Response {
  const next = new Response(response.body, response);
  next.headers.set("Content-Signal", SIGNAL);
  return next;
}

export function llmsTxt(): string {
  return `# Helomatic
> Agentic automation company. Hello automation. She Runs Code / Houston. Website design is first.

This origin is the house Worker. The mark is Helomatic (one L).

Website design is Live. Hire: Reprint or start from a brief. Reprint a live URL or start from a brief, then monthly hosting. Software design, Agent design, Automation, Knowledge, and Voice: Private partners only.

## Surfaces
- [House](/): the Website design desk in the first viewport
- [Practices](/practices): Website design, Software design, Agent design, Automation, Knowledge, Voice
- [Web](/web): reprint or scratch, plus hosting (amounts unpublished)
- [Software](/software)
- [Agent design](/agents)
- [Automation](/automation)
- [Knowledge](/knowledge)
- [Voice](/voice)
- [Choose](/choose)
- [Desk](/desk): session-gated loop
- [MCP](/mcp)
- [Agent](/agent): desk chat
- [Live](/live): durable chat
- [Visitors](/visitors): presence globe, not on the house landing
- [Full text](/llms-full.txt)
- [Index](/index.json)

## Commerce
- Product that prints: Website design (Web)
- Cart: one-time Setup + monthly Hosting (unpublished TEST prices; amounts are not listed here)
- Software design, Agent design, Automation, Knowledge, Voice: Private partners only. No extra Stripe SKUs.

## Rules
- Operator public face: She Runs Code / Houston
- Do not invent testimonials, client logos, metrics, or public prices
- Do not treat random workers.dev hosts as this desk
`;
}

export function llmsFullTxt(): string {
  return `${llmsTxt()}

## Loop
land → desk signup → /choose → brief (reprint URL or scratch, assets on this origin) → session-gated preview on this Worker → Print it → Stripe Checkout TEST mixed cart → webhook starts a job → changes → publish intent (subdomain placeholder).

## What this is not
Not a stub landing. Not a contact form. Not a template gallery. Not an agent portal. Not a white-label theme switcher.
`;
}

export function agentIndex() {
  return {
    name: "Helomatic",
    tagline: "Agentic automation company. Website design first.",
    sku: [{ slug: "web", title: "Website design", kind: "website_reprint_or_scratch_plus_hosting" }],
    practices: [
      "Website design",
      "Software design",
      "Agent design",
      "Automation",
      "Knowledge",
      "Voice",
    ],
    operator: "She Runs Code",
    city: "Houston",
    surfaces: [
      "/llms.txt",
      "/llms-full.txt",
      "/index.json",
      "/jsonld",
      "/robots.txt",
      "/web.md",
      "/desk.md",
      "/practices",
      "/software",
      "/agents",
      "/automation",
      "/knowledge",
      "/voice",
      "/mcp",
    ],
  };
}

export function jsonLd() {
  return {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Helomatic",
    description:
      "Helomatic is an agentic automation company. Website design is Live. She Runs Code / Houston.",
    url: "/",
    areaServed: { "@type": "City", name: "Houston" },
    makesOffer: {
      "@type": "Offer",
      itemOffered: {
        "@type": "Service",
        name: "Website design",
        description: "Reprint a live site or start from a brief, plus monthly hosting. Amounts unpublished.",
      },
    },
  };
}

export function robotsTxt(): string {
  return `User-agent: *
Allow: /
Allow: /llms.txt
Allow: /llms-full.txt
Allow: /index.json
Allow: /jsonld
Allow: /web.md
Allow: /desk.md

# Content-Signal: ${SIGNAL}
`;
}

export function markdownPage(slug: string): string | null {
  if (slug === "web") {
    return `# Web

SKU 1 on Helomatic. Reprint a live site, or start from a brief. Monthly hosting after print. She Runs Code / Houston. Amounts unpublished.
`;
  }
  if (slug === "desk") {
    return `# Desk

Open a desk on Helomatic. That is contact. Choose Website design. File a brief. Preview is session-gated on this Worker. Print it starts a TEST mixed cart (setup + monthly hosting). Software design, Agent design, Automation, Knowledge, and Voice are private partners only.
`;
  }
  return null;
}

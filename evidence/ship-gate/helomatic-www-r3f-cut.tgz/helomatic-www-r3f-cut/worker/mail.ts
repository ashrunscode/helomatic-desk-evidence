import { nid, now } from "./ids";

export async function queueMail(
  db: D1Database,
  to: string,
  subject: string,
  body: string,
): Promise<void> {
  await db
    .prepare(
      `INSERT INTO mail_outbox (id, to_email, subject, body, provider, sent, created_at)
       VALUES (?, ?, ?, ?, 'resend_stub', 0, ?)`,
    )
    .bind(nid("mail"), to, subject, body, now())
    .run();
}

export type Brief = {
  business_name?: string;
  hours?: string;
  about?: string;
  phone?: string;
  city?: string;
};

function esc(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

export function renderPreviewHtml(opts: {
  site: SiteRow;
  brief: Brief;
  assets: BriefAssetRow[];
}): string {
  const name = esc(opts.brief.business_name || opts.site.name || "Untitled desk");
  const hours = esc(opts.brief.hours || "Hours on file with the desk");
  const about = esc(opts.brief.about || "A site brief is on the desk. The shop has not set this copy yet.");
  const phone = esc(opts.brief.phone || "");
  const city = esc(opts.brief.city || "");
  const logo = opts.assets.find((a) => a.kind === "logo");
  const photos = opts.assets.filter((a) => a.kind === "photo");
  const photoMarkup = photos
    .map(
      (p) =>
        `<figure><img src="/assets/${p.id}" alt="" /><figcaption>${esc(p.filename || "")}</figcaption></figure>`,
    )
    .join("");

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${name}</title>
  <style>
    :root { color-scheme: light; }
    * { box-sizing: border-box; }
    body { margin: 0; font: 18px/1.5 "Instrument Serif", "Iowan Old Style", Georgia, serif; color: #1b1814; background: #f4efe6; }
    header { padding: 48px 8vw 24px; border-bottom: 1px solid #d8d0c3; }
    .mark { display: flex; gap: 16px; align-items: center; }
    .mark img { width: 64px; height: 64px; object-fit: cover; border-radius: 4px; }
    h1 { font-size: clamp(2rem, 5vw, 3.4rem); margin: 0; letter-spacing: -0.03em; }
    .meta { color: #5c564c; font-size: 0.92rem; margin-top: 8px; }
    main { padding: 32px 8vw 80px; max-width: 920px; }
    .hours { font-family: ui-monospace, "IBM Plex Mono", monospace; font-size: 0.86rem; letter-spacing: 0.04em; text-transform: uppercase; color: #6a4330; margin: 24px 0; }
    .photos { display: grid; gap: 16px; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); margin-top: 36px; }
    figure { margin: 0; }
    figure img { width: 100%; height: 220px; object-fit: cover; border-radius: 2px; }
    figcaption { font-size: 0.75rem; color: #7a7468; margin-top: 6px; }
  </style>
</head>
<body>
  <header>
    <div class="mark">
      ${logo ? `<img src="/assets/${logo.id}" alt="" />` : ""}
      <div>
        <h1>${name}</h1>
        <div class="meta">${city}${phone ? ` · ${phone}` : ""}</div>
      </div>
    </div>
  </header>
  <main>
    <p>${about}</p>
    <p class="hours">${hours}</p>
    <div class="photos">${photoMarkup}</div>
  </main>
</body>
</html>`;
}

export function gatedPreviewPage(): string {
  return `<!doctype html><html><head><meta charset="utf-8"><title>Preview · Reprint or start from a brief.</title>
<style>body{margin:0;background:#14110e;color:#f4efe6;font:16px/1.5 "Instrument Sans",system-ui,sans-serif;padding:48px}</style>
</head><body><p>This preview is gated to a Helomatic desk session. Open a desk, then return.</p></body></html>`;
}

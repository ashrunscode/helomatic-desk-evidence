export const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS partners (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  branding_json TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sites (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  sku TEXT NOT NULL DEFAULT 'web',
  mode TEXT,
  source_url TEXT,
  name TEXT,
  brief_json TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  preview_ready INTEGER NOT NULL DEFAULT 0,
  publish_intent INTEGER NOT NULL DEFAULT 0,
  subdomain_placeholder TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  site_id TEXT,
  kind TEXT NOT NULL,
  status TEXT NOT NULL,
  payload_json TEXT,
  stripe_session_id TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS ledger (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  job_id TEXT,
  site_id TEXT,
  kind TEXT NOT NULL,
  stripe_event_id TEXT,
  stripe_object_id TEXT,
  status TEXT NOT NULL,
  note TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS waitlist (
  id TEXT PRIMARY KEY,
  partner_id TEXT,
  customer_id TEXT NOT NULL,
  bay_index INTEGER NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS brief_assets (
  id TEXT PRIMARY KEY,
  site_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  r2_key TEXT NOT NULL,
  kind TEXT NOT NULL,
  filename TEXT,
  content_type TEXT,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS mail_outbox (
  id TEXT PRIMARY KEY,
  to_email TEXT NOT NULL,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  provider TEXT NOT NULL DEFAULT 'resend_stub',
  sent INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS stripe_events (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  processed_at INTEGER NOT NULL
);
`;

let ready = false;

export async function ensureSchema(db: D1Database): Promise<void> {
  if (ready) return;
  const row = await db
    .prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='customers'")
    .first();
  if (!row) {
    for (const statement of SCHEMA_SQL.split(";").map((s) => s.trim()).filter(Boolean)) {
      await db.prepare(statement).run();
    }
  }
  ready = true;
}

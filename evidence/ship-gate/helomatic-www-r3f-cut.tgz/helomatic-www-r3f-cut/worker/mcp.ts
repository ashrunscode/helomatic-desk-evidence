import { McpServer } from "@modelcontextprotocol/server";
import { createMcpHandler } from "agents/mcp/server";
import { z } from "zod";

function createServer() {
  const server = new McpServer({
    name: "helomatic",
    version: "0.1.0",
  });

  server.registerTool(
    "desk_loop",
    {
      description:
        "Describe the Helomatic desk loop. No prices, no invented SKUs.",
      inputSchema: { detail: z.string().optional() },
    },
    async () => ({
      content: [
        {
          type: "text",
          text: "Helomatic is an agentic automation company. She Runs Code / Houston. Open a desk, choose Website design, file a brief (reprint URL or scratch), see a session-gated preview on this Worker, Print it (Stripe TEST mixed cart: Setup + Hosting, unpublished), webhook starts a job, file changes, file publish intent. Software design, Agent design, Automation, Knowledge, and Voice are private partners only. A human still does live DNS, first live charge, and tax.",
        },
      ],
    }),
  );

  server.registerTool(
    "list_skus",
    {
      description: "List named SKUs. Only Website design is a Stripe SKU.",
      inputSchema: { unused: z.string().optional() },
    },
    async () => ({
      content: [
        {
          type: "text",
          text: JSON.stringify({
            skus: [
              {
                slug: "web",
                title: "Web",
                note: "Reprint or from-scratch site plus monthly hosting. Prices unpublished.",
              },
            ],
            private_practices: [
              "Software design",
              "Agent design",
              "Automation",
              "Knowledge",
              "Voice",
            ],
          }),
        },
      ],
    }),
  );

  return server;
}

export function mcpFetch(
  request: Request,
  env: Env,
  ctx: ExecutionContext,
): Promise<Response> {
  return createMcpHandler(createServer, { route: "/mcp" })(request, env, ctx);
}

type Turn = { role: "user" | "pax"; text: string; at: number };

export class AgentDesk {
  ctx: DurableObjectState;
  env: Env;

  constructor(ctx: DurableObjectState, env: Env) {
    this.ctx = ctx;
    this.env = env;
  }

  async fetch(request: Request): Promise<Response> {
    if (request.method === "GET") {
      const history = (await this.ctx.storage.get<Turn[]>("turns")) ?? [];
      return Response.json({ messages: history });
    }
    if (request.method !== "POST") return new Response("method", { status: 405 });
    const body = (await request.json()) as { text?: string };
    const text = (body.text ?? "").trim().slice(0, 800);
    if (!text) return Response.json({ error: "empty" }, { status: 400 });
    const history = (await this.ctx.storage.get<Turn[]>("turns")) ?? [];
    const user: Turn = { role: "user", text, at: Date.now() };
    const pax: Turn = { role: "pax", text: reply(text), at: Date.now() };
    history.push(user, pax);
    await this.ctx.storage.put("turns", history.slice(-80));
    return Response.json({ messages: [user, pax] });
  }
}

function reply(text: string): string {
  const q = text.toLowerCase();
  if (q.includes("price") || q.includes("cost") || q.includes("$")) {
    return "Amounts stay unpublished on the house. Print it opens Stripe TEST Checkout when keys are set; otherwise you get a TEST stub. A human still owns the first live charge and tax.";
  }
  if (q.includes("dns") || q.includes("domain") || q.includes("publish")) {
    return "Publish intent files a subdomain placeholder. Live DNS is still a human step. This Worker will not attach apex.";
  }
  if (q.includes("bay") || q.includes("sku") || q.includes("other")) {
    return "Website design is Live. Software design, Agent design, Automation, Knowledge, and Voice are private partners only. No extra Stripe SKUs.";
  }
  if (q.includes("agent") || q.includes("white") || q.includes("partner")) {
    return "This desk is the house. There is no agent portal and no white-label switcher on the public site.";
  }
  return "Open a desk, choose Website design, file a brief, preview on this site, then Print it. The other practices are private partners only. She Runs Code fulfills from Houston after the job lands.";
}

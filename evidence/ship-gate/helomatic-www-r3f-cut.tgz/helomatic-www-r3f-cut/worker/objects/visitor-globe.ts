type Visitor = {
  id: string;
  lat: number;
  lng: number;
};

export class VisitorGlobe {
  ctx: DurableObjectState;
  env: Env;
  visitors: Map<WebSocket, Visitor>;

  constructor(ctx: DurableObjectState, env: Env) {
    this.ctx = ctx;
    this.env = env;
    this.visitors = new Map();
  }

  async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("expected websocket", { status: 426 });
    }
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1]);
    const visitor = locate(request);
    this.visitors.set(pair[1], visitor);
    pair[1].send(JSON.stringify({ type: "you", visitor, visitors: [...this.visitors.values()] }));
    this.broadcast({ type: "join", visitor });
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async webSocketClose(ws: WebSocket): Promise<void> {
    const visitor = this.visitors.get(ws);
    this.visitors.delete(ws);
    if (visitor) this.broadcast({ type: "leave", id: visitor.id });
    ws.close();
  }

  broadcast(payload: unknown): void {
    const body = JSON.stringify(payload);
    for (const client of this.ctx.getWebSockets()) {
      client.send(body);
    }
  }
}

function locate(request: Request): Visitor {
  const country = request.headers.get("cf-ipcountry");
  const latHeader = request.headers.get("cf-iplatitude");
  const lngHeader = request.headers.get("cf-iplongitude");
  const lat = latHeader ? Number(latHeader) : jitter(country);
  const lng = lngHeader ? Number(lngHeader) : jitter(country, true);
  return { id: crypto.randomUUID(), lat, lng };
}

function jitter(country: string | null, lng = false): number {
  const seed = country ? country.charCodeAt(0) : 40;
  const base = lng ? (seed - 65) * 4 : (seed - 70) * 1.2;
  return base + (Math.random() - 0.5) * 12;
}

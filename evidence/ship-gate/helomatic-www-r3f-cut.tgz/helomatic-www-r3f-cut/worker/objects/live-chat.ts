type ChatMessage = {
  id: string;
  name: string;
  text: string;
  at: number;
};

export class LiveChat {
  ctx: DurableObjectState;
  env: Env;

  constructor(ctx: DurableObjectState, env: Env) {
    this.ctx = ctx;
    this.env = env;
  }

  async fetch(request: Request): Promise<Response> {
    if (request.headers.get("Upgrade") !== "websocket") {
      const history = (await this.ctx.storage.get<ChatMessage[]>("history")) ?? [];
      return Response.json({ messages: history.slice(-80) });
    }
    const pair = new WebSocketPair();
    this.ctx.acceptWebSocket(pair[1]);
    const history = (await this.ctx.storage.get<ChatMessage[]>("history")) ?? [];
    pair[1].send(JSON.stringify({ type: "hello", messages: history.slice(-80) }));
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async webSocketMessage(ws: WebSocket, message: string | ArrayBuffer): Promise<void> {
    if (typeof message !== "string") return;
    let parsed: { name?: string; text?: string };
    try {
      parsed = JSON.parse(message) as { name?: string; text?: string };
    } catch {
      return;
    }
    const text = (parsed.text ?? "").trim().slice(0, 500);
    if (!text) return;
    const item: ChatMessage = {
      id: crypto.randomUUID(),
      name: (parsed.name ?? "desk").slice(0, 40),
      text,
      at: Date.now(),
    };
    const history = (await this.ctx.storage.get<ChatMessage[]>("history")) ?? [];
    history.push(item);
    await this.ctx.storage.put("history", history.slice(-200));
    for (const client of this.ctx.getWebSockets()) {
      client.send(JSON.stringify({ type: "message", message: item }));
    }
  }

  async webSocketClose(ws: WebSocket): Promise<void> {
    ws.close();
  }
}

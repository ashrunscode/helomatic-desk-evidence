import Stripe from "stripe";
import { nid, now } from "./ids";
import { queueMail } from "./mail";

export function stripeReady(env: Env): boolean {
  return Boolean(
    env.STRIPE_RESTRICTED_KEY && env.STRIPE_PRICE_SETUP && env.STRIPE_PRICE_HOSTING,
  );
}

export function stripeClient(env: Env): Stripe {
  if (!env.STRIPE_RESTRICTED_KEY) {
    throw new Error("Stripe TEST key missing");
  }
  return new Stripe(env.STRIPE_RESTRICTED_KEY, {
    httpClient: Stripe.createFetchHttpClient(),
    typescript: true,
  });
}

export async function createPrintCheckout(
  env: Env,
  origin: string,
  site: SiteRow,
  customer: CustomerRow,
): Promise<string> {
  const stripe = stripeClient(env);
  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    client_reference_id: site.id,
    customer_email: customer.email,
    success_url: `${origin}/job?site=${site.id}&paid=1`,
    cancel_url: `${origin}/preview/${site.id}`,
    metadata: {
      site_id: site.id,
      customer_id: customer.id,
      partner_id: customer.partner_id ?? "",
      sku: "web",
    },
    line_items: [
      { price: env.STRIPE_PRICE_SETUP!, quantity: 1 },
      { price: env.STRIPE_PRICE_HOSTING!, quantity: 1 },
    ],
  });
  if (!session.url) throw new Error("Checkout session missing url");
  return session.url;
}

export async function recordPrintJob(
  db: D1Database,
  site: SiteRow,
  customer: CustomerRow,
  opts: { stripeSessionId?: string | null; stub: boolean },
): Promise<JobRow> {
  const created = now();
  const jobId = nid("job");
  await db
    .prepare(
      `INSERT INTO jobs (id, partner_id, customer_id, site_id, kind, status, payload_json, stripe_session_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, 'print', 'queued', ?, ?, ?, ?)`,
    )
    .bind(
      jobId,
      customer.partner_id,
      customer.id,
      site.id,
      JSON.stringify({ sku: "web", stub: opts.stub }),
      opts.stripeSessionId ?? null,
      created,
      created,
    )
    .run();

  for (const kind of ["setup", "hosting"] as const) {
    await db
      .prepare(
        `INSERT INTO ledger (id, partner_id, customer_id, job_id, site_id, kind, stripe_object_id, status, note, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        nid("led"),
        customer.partner_id,
        customer.id,
        jobId,
        site.id,
        kind,
        opts.stripeSessionId ?? null,
        opts.stub ? "stub" : "pending",
        opts.stub ? "TEST stub — Stripe keys not configured" : "TEST checkout",
        created,
      )
      .run();
  }

  await db
    .prepare("UPDATE sites SET status = ?, updated_at = ? WHERE id = ?")
    .bind("printed", created, site.id)
    .run();

  await queueMail(
    db,
    customer.email,
    "Print job on the desk",
    `Job ${jobId} is queued on the Helomatic desk. This mail was stubbed and not sent.`,
  );

  const job = await db.prepare("SELECT * FROM jobs WHERE id = ?").bind(jobId).first<JobRow>();
  if (!job) throw new Error("job insert failed");
  return job;
}

export async function handleStripeWebhook(env: Env, request: Request): Promise<Response> {
  if (!env.STRIPE_RESTRICTED_KEY || !env.STRIPE_WEBHOOK_SECRET) {
    return Response.json({ error: "Stripe webhook is not configured" }, { status: 503 });
  }
  const signature = request.headers.get("stripe-signature");
  if (!signature) return new Response("missing signature", { status: 400 });
  const raw = await request.text();
  const stripe = stripeClient(env);
  let event: Stripe.Event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      raw,
      signature,
      env.STRIPE_WEBHOOK_SECRET,
      undefined,
      Stripe.createSubtleCryptoProvider(),
    );
  } catch {
    return new Response("bad signature", { status: 400 });
  }

  const seen = await env.DB.prepare("SELECT id FROM stripe_events WHERE id = ?")
    .bind(event.id)
    .first();
  if (seen) return Response.json({ ok: true, dup: true });

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const siteId = session.metadata?.site_id;
    const customerId = session.metadata?.customer_id;
    if (siteId && customerId) {
      const site = await env.DB.prepare("SELECT * FROM sites WHERE id = ?")
        .bind(siteId)
        .first<SiteRow>();
      const customer = await env.DB.prepare("SELECT * FROM customers WHERE id = ?")
        .bind(customerId)
        .first<CustomerRow>();
      if (site && customer) {
        const existing = await env.DB.prepare(
          "SELECT id FROM jobs WHERE stripe_session_id = ?",
        )
          .bind(session.id)
          .first();
        if (!existing) {
          await recordPrintJob(env.DB, site, customer, {
            stripeSessionId: session.id,
            stub: false,
          });
        }
      }
    }
  }

  await env.DB.prepare("INSERT INTO stripe_events (id, type, processed_at) VALUES (?, ?, ?)")
    .bind(event.id, event.type, now())
    .run();

  return Response.json({ ok: true });
}
